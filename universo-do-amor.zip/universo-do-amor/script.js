/* =========================================================
   UNIVERSO DO AMOR — script.js
   Galáxia 3D de partículas rosa, coração de partículas,
   frases orbitando, cartões de memória e final.
   ========================================================= */

import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

/* =========================================================
   1. CONTEÚDO — edite aqui textos e fotos
   ========================================================= */
const CONFIG = {
  // Frases que "passam" pela galáxia (troque à vontade)
  phrases: [
    'TE AMO', 'AMOR DA MINHA VIDA', 'AMOR ETERNO', 'VOCÊ É MAGIA', 'FELIZ ANIVERSÁRIO',
    'PRA SEMPRE', 'MINHA VIDA', 'COM VOCÊ', 'TE QUERO PERTO', 'MINHA PESSOA FAVORITA', 'PRA VOCÊ',
  ],
  // Uma lembrança por planeta, na ordem: Vênus, Marte, Júpiter, Saturno e Netuno.
  // As fotos ficam em assets/memory-1.jpg ... assets/memory-5.jpg
  memories: [
    { title: 'Amor da Minha Vida', image: 'assets/memory-1.jpg',
      text: 'Com você, até os dias mais simples viram uma história que eu quero contar pra sempre.' },
    { title: 'Pra Sempre', image: 'assets/memory-2.jpg',
      text: 'Se eu pudesse escolher de novo, te encontraria em cada vida e em cada universo.' },
    { title: 'Pra Você', image: 'assets/memory-3.jpg',
      text: 'Cada estrela desse céu é um pensamento meu viajando até você.' },
    { title: 'Meu Lugar Favorito', image: 'assets/memory-4.jpg',
      text: 'Não importa onde a gente esteja: se for com você, é o meu lugar favorito.' },
    { title: 'Minha Pessoa Favorita', image: 'assets/memory-5.jpg',
      text: 'Você é a minha calma, a minha alegria e a minha melhor companhia.' },
  ],
  finalTitle: 'Uma Galáxia de Amor para Você',
  finalText: 'Porque, entre todos os universos,<br>eu sempre escolheria o nosso.',
  ui: {
    next: 'Próxima lembrança ♥',
    finish: 'Continuar ♥',
    hint: 'Toque nos planetas para abrir as lembranças ♥',
  },
};

/* Ajustes visuais rápidos */
const LOOK = {
  bloomStrength: 0.9,     // brilho neon (sobe = mais glow)
  bloomRadius: 0.5,
  bloomThreshold: 0.18,
  galaxySpinSpeed: 0.025, // rotação lenta da galáxia (rad/s)
  fogDensity: 0.010,
  textFill: '#fff2c2',    // cor de destaque das frases (miolo)
  textGlow: '#ff9f5a',    // brilho das frases
  planetBrightness: 0.95, // luz dos planetas
};

/* =========================================================
   2. CONSTANTES, QUALIDADE E UTILITÁRIOS
   ========================================================= */
const TAU = Math.PI * 2;
const GALAXY_R = 11;
const HEART_SCALE = 0.25;
const HEART_Y = 3.6;
const HEART_YOFF = 2.5; // centraliza a curva do coração em y = 0

const isMobile = window.innerWidth < 768 || /Android|iPhone|iPad|iPod|Mobi/i.test(navigator.userAgent);
const lowEnd = (navigator.deviceMemory && navigator.deviceMemory <= 4) ||
               (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const Q = {
  galaxy:   isMobile ? (lowEnd ? 12000 : 18000) : 40000,
  haze:     isMobile ? 1800 : 5000,
  stars:    isMobile ? 3500 : 7000,
  heart:    isMobile ? 5500 : 11000,
  core:     isMobile ? 1800 : 3500,
  floats:   isMobile ? 26 : 40,
  escapers: isMobile ? 150 : 300,
  sparks:   isMobile ? 80 : 150,
  pixelRatio: Math.min(window.devicePixelRatio || 1, isMobile ? 1.5 : 2),
};

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const lerp = (a, b, t) => a + (b - a) * t;
const rand = (a, b) => a + Math.random() * (b - a);
const randSigned = (p) => Math.pow(Math.random(), p) * (Math.random() < 0.5 ? 1 : -1);
const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 1.5;
const easeInOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const easeOut = (t) => 1 - Math.pow(1 - t, 3);
const $ = (s) => document.querySelector(s);
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

/* =========================================================
   3. ESTADO GLOBAL
   ========================================================= */
let renderer, scene, camera, composer, bloomPass, clock;
let W = window.innerWidth, H = window.innerHeight, aspect = W / H;
let fit = 1, fitSoft = 1, textScale = 1, currentPR = Q.pixelRatio;
let time = 0, enterAt = null;

let starsGroup, galaxyTilt, galaxySpin, galaxyPoints, hazePoints, coreGroup, coreGlow, coreGlow2;
let heartGroup, heartPoints, textGroup, floatGroup, planetGroup;
let planets = [], planetScale = 1, planetMotion = 1, memIndex = -1;
const visited = new Set();
let escapers, sparks, burst;

const mats = {};
const materials = [];
const reveal = { stars: 0, galaxy: 0, haze: 0, core: 0, heart: 0, sparks: 0, escapers: 0, floats: 0, textT: -10 };

const shared = {
  uTime: { value: 0 },
  uScale: { value: 500 },
  uAspect: { value: 1 },
  uPointer: { value: new THREE.Vector2(9, 9) },
  uPointerStr: { value: 0 },
};

const pointer = { x: 0, y: 0, tx: 0, ty: 0, active: false, isTouch: false };
const parallax = { x: 0, y: 0 };
const cam = {
  pos: new THREE.Vector3(), look: new THREE.Vector3(),
  tPos: new THREE.Vector3(), tLook: new THREE.Vector3(),
  rate: 0.8, view: null, soft: false,
};
const heartState = { boost: 1, target: 1, kick: 0 };
const perf = { acc: 0, n: 0, done: false };

const ui = {};
let cardEls = [];
let phase = 'intro';   // intro | galaxy | memory | transition | final
let musicOn = false;
const timers = [];

/* =========================================================
   4. SHADERS DAS PARTÍCULAS
   ========================================================= */
const VERT = /* glsl */`
uniform float uTime;
uniform float uScale;
uniform float uReveal;
uniform float uRevealFrom;
uniform float uScatter;
uniform float uSwirl;
uniform float uFog;
uniform float uAlpha;
uniform float uPointerMul;
uniform float uPointerStr;
uniform float uWobble;
uniform float uSizeMul;
uniform float uAspect;
uniform vec2 uPointer;

attribute float aSize;
attribute vec3 aColor;
attribute float aRand;
#ifdef USE_LIFE
attribute float aLife;
#endif

varying vec3 vColor;
varying float vAlpha;

void main() {
  vec3 p = position;
  float rv = 1.0;

  #ifdef USE_LIFE
    rv = uReveal;
  #else
    rv = smoothstep(0.0, 1.0, clamp(uReveal * 1.6 - aRand * 0.6, 0.0, 1.0));
    float ph = aRand * 6.2831853;
    // respiração individual de cada partícula
    p += vec3(cos(uTime * 0.35 + ph * 7.0),
              sin(uTime * 0.55 + ph * 5.0) * 0.6,
              sin(uTime * 0.30 + ph * 3.0)) * 0.05 * uWobble;
    // entrada cinematográfica: espiral + dispersão
    float ang = (1.0 - rv) * uSwirl;
    float cs = cos(ang);
    float sn = sin(ang);
    p.xz = mat2(cs, sn, -sn, cs) * p.xz;
    vec3 dir = vec3(cos(aRand * 91.0), sin(aRand * 57.0), cos(aRand * 33.0));
    p = p * mix(uRevealFrom, 1.0, rv) + dir * (1.0 - rv) * uScatter;
  #endif

  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  vec4 clip = projectionMatrix * mv;

  // partículas reagem levemente ao mouse / toque (em espaço de tela)
  if (uPointerMul > 0.0) {
    vec2 ndc = clip.xy / clip.w;
    vec2 d = (ndc - uPointer) * vec2(uAspect, 1.0);
    float f = exp(-dot(d, d) * 14.0) * uPointerStr * uPointerMul;
    clip.xy += normalize(d + vec2(0.00001)) / vec2(uAspect, 1.0) * f * 0.07 * clip.w;
  }
  gl_Position = clip;

  float dist = max(-mv.z, 0.1);
  float sz;
  #ifdef USE_LIFE
    vAlpha = aLife * uAlpha * uReveal;
    sz = aSize * uSizeMul * (0.45 + 0.55 * aLife);
  #else
    float base = mix(0.4, 1.0, fract(aRand * 13.37));
    float tw = 0.8 + 0.2 * sin(uTime * (1.0 + aRand * 2.5) + aRand * 80.0);
    vAlpha = base * tw * rv * uAlpha;
    sz = aSize * uSizeMul * mix(0.6, 1.0, rv);
  #endif

  vAlpha *= exp(-pow(uFog * dist, 2.0));
  gl_PointSize = clamp(sz * uScale / dist, 1.0, 46.0);
  vColor = aColor;
}
`;

const FRAG = /* glsl */`
varying vec3 vColor;
varying float vAlpha;

void main() {
  vec2 c = gl_PointCoord - vec2(0.5);
  float d = length(c) * 2.0;
  if (d > 1.0) discard;
  float f = 1.0 - d;
  float a = f * f * (0.55 + 0.9 * f * f);
  vec3 col = vColor * (0.75 + 0.9 * f * f * f);
  gl_FragColor = vec4(col, clamp(a, 0.0, 1.0) * vAlpha);
}
`;

function makeParticleMaterial(opts = {}) {
  const o = Object.assign({
    alpha: 1, fog: LOOK.fogDensity, revealFrom: 1, scatter: 0, swirl: 0,
    pointer: 1, wobble: 1, sizeMul: 1, life: false,
  }, opts);

  const m = new THREE.ShaderMaterial({
    uniforms: {
      uTime: shared.uTime, uScale: shared.uScale, uAspect: shared.uAspect,
      uPointer: shared.uPointer, uPointerStr: shared.uPointerStr,
      uReveal: { value: 0 }, uRevealFrom: { value: o.revealFrom },
      uScatter: { value: o.scatter }, uSwirl: { value: o.swirl },
      uFog: { value: o.fog }, uAlpha: { value: o.alpha },
      uPointerMul: { value: o.pointer }, uWobble: { value: o.wobble },
      uSizeMul: { value: o.sizeMul },
    },
    vertexShader: VERT,
    fragmentShader: FRAG,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    defines: o.life ? { USE_LIFE: '' } : {},
  });
  materials.push(m);
  return m;
}

function makeGeometry(pos, col, size, rnd) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('aColor', new THREE.BufferAttribute(col, 3));
  g.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
  g.setAttribute('aRand', new THREE.BufferAttribute(rnd, 1));
  return g;
}

/* =========================================================
   5. INIT
   ========================================================= */
function init() {
  ui.intro = $('#intro'); ui.enter = $('#enter'); ui.veil = $('#veil');
  ui.cards = $('#cards'); ui.final = $('#final'); ui.next = $('#next');
  ui.sound = $('#sound'); ui.hint = $('#hint'); ui.music = $('#music');
  ui.replay = $('#replay'); ui.canvas = $('#scene');
  ui.hint.textContent = CONFIG.ui.hint;

  try {
    renderer = new THREE.WebGLRenderer({
      canvas: ui.canvas, antialias: false, alpha: false, powerPreference: 'high-performance',
    });
  } catch (err) {
    showFallback();
    return;
  }
  renderer.setPixelRatio(Q.pixelRatio);
  renderer.setSize(W, H, false);
  renderer.setClearColor(0x030006, 1);

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x030006);
  scene.fog = new THREE.FogExp2(0x030006, LOOK.fogDensity);

  camera = new THREE.PerspectiveCamera(55, W / H, 0.1, 1000);
  clock = new THREE.Clock();

  createStars();
  createGalaxy();
  createCore();
  createHeart();
  createTextParticles();
  createFloatingHearts();
  createPlanets();
  createEscapers();
  createBurst();
  createMemoryCards();

  setupCamera();
  setupPostProcessing();
  setupControls();
  handleResize();
  snapCamera();

  animate();
}

function showFallback() {
  const p = document.createElement('p');
  p.className = 'noscript';
  p.textContent = 'Seu navegador não conseguiu abrir este universo (WebGL indisponível). Tente o Chrome, Safari ou Firefox atualizados.';
  document.body.appendChild(p);
}

/* =========================================================
   6. ESTRELAS DE FUNDO
   ========================================================= */
function createStars() {
  starsGroup = new THREE.Group();
  scene.add(starsGroup);

  const n = Q.stars;
  const pos = new Float32Array(n * 3), col = new Float32Array(n * 3);
  const size = new Float32Array(n), rnd = new Float32Array(n);
  const c = new THREE.Color();
  const palette = [0xffffff, 0xffffff, 0xffe3f1, 0xffc8e4, 0xd9c2ff];

  for (let i = 0; i < n; i++) {
    const v = new THREE.Vector3(gauss(), gauss(), gauss()).normalize().multiplyScalar(rand(70, 190));
    pos.set([v.x, v.y, v.z], i * 3);
    c.set(pick(palette));
    const b = rand(0.5, 1);
    col.set([c.r * b, c.g * b, c.b * b], i * 3);
    size[i] = rand(0.25, 0.85);
    rnd[i] = Math.random();
  }
  mats.stars = makeParticleMaterial({ alpha: 0.55, fog: 0, pointer: 0, wobble: 0, sizeMul: 1 });
  const pts = new THREE.Points(makeGeometry(pos, col, size, rnd), mats.stars);
  pts.frustumCulled = false;
  starsGroup.add(pts);
}

/* =========================================================
   7. GALÁXIA
   ========================================================= */
function buildGalaxyGeometry(count, o) {
  const pos = new Float32Array(count * 3), col = new Float32Array(count * 3);
  const size = new Float32Array(count), rnd = new Float32Array(count);
  const cIn = new THREE.Color(0xffc2e0), cMid = new THREE.Color(0xff2fa0);
  const cOut = new THREE.Color(0xd4145a), cViolet = new THREE.Color(0x8a3cff);
  const tmp = new THREE.Color();

  for (let i = 0; i < count; i++) {
    const r = Math.pow(Math.random(), o.bias) * GALAXY_R;
    const rr = r / GALAXY_R;
    const branchAngle = ((i % o.branches) / o.branches) * TAU;
    const angle = branchAngle + r * o.spin;

    const spread = o.randomness * (0.4 + r * 0.35);
    const ox = randSigned(o.power) * spread;
    const oz = randSigned(o.power) * spread;
    const oy = randSigned(2.2) * o.thickness * (1.6 * Math.exp(-r * 0.3) + 0.25);

    pos[i * 3]     = Math.cos(angle) * r + ox;
    pos[i * 3 + 1] = oy;
    pos[i * 3 + 2] = Math.sin(angle) * r + oz;

    if (rr < 0.35) tmp.copy(cIn).lerp(cMid, rr / 0.35);
    else tmp.copy(cMid).lerp(cOut, (rr - 0.35) / 0.65);
    const roll = Math.random();
    if (roll < 0.09 && rr > 0.3) tmp.lerp(cViolet, 0.55);
    else if (roll > 0.93) tmp.set(0xffffff);
    const b = rand(0.65, 1.2);
    col[i * 3] = tmp.r * b; col[i * 3 + 1] = tmp.g * b; col[i * 3 + 2] = tmp.b * b;

    size[i] = o.sizeMin + Math.pow(Math.random(), 4) * (o.sizeMax - o.sizeMin);
    rnd[i] = Math.random();
  }
  return makeGeometry(pos, col, size, rnd);
}

function createGalaxy() {
  // tilt (inclinação fixa) > spin (rotação no próprio plano do disco)
  galaxyTilt = new THREE.Group();
  galaxyTilt.rotation.set(0.16, 0, -0.24);
  scene.add(galaxyTilt);
  galaxySpin = new THREE.Group();
  galaxyTilt.add(galaxySpin);

  mats.galaxy = makeParticleMaterial({ alpha: 0.95, revealFrom: 1.9, swirl: 2.6, wobble: 1 });
  galaxyPoints = new THREE.Points(
    buildGalaxyGeometry(Q.galaxy, {
      branches: 4, spin: 0.52, randomness: 0.5, power: 2.6, bias: 1.7,
      sizeMin: 0.05, sizeMax: 0.22, thickness: 1.1,
    }), mats.galaxy);
  galaxyPoints.frustumCulled = false;
  galaxySpin.add(galaxyPoints);

  // névoa fina de partículas grandes e fracas, dá corpo aos braços
  mats.haze = makeParticleMaterial({ alpha: 0.11, revealFrom: 1.7, swirl: 2.2, wobble: 3 });
  hazePoints = new THREE.Points(
    buildGalaxyGeometry(Q.haze, {
      branches: 4, spin: 0.52, randomness: 0.75, power: 1.8, bias: 1.15,
      sizeMin: 0.7, sizeMax: 1.7, thickness: 0.9,
    }), mats.haze);
  hazePoints.frustumCulled = false;
  galaxySpin.add(hazePoints);
}

/* =========================================================
   8. NÚCLEO (redemoinho luminoso)
   ========================================================= */
function makeGlowTexture(stops) {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const ctx = c.getContext('2d');
  const g = ctx.createRadialGradient(128, 128, 0, 128, 128, 128);
  stops.forEach(([o, col]) => g.addColorStop(o, col));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 256);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function createCore() {
  coreGroup = new THREE.Group();
  galaxySpin.add(coreGroup);

  const n = Q.core;
  const pos = new Float32Array(n * 3), col = new Float32Array(n * 3);
  const size = new Float32Array(n), rnd = new Float32Array(n);
  const cA = new THREE.Color(0xffd6ec), cB = new THREE.Color(0xff5fb0), tmp = new THREE.Color();

  for (let i = 0; i < n; i++) {
    const r = Math.pow(Math.random(), 1.4) * 1.9;
    const a = ((i % 3) / 3) * TAU + r * 3.4 + gauss() * 0.28;
    pos[i * 3] = Math.cos(a) * r;
    pos[i * 3 + 1] = gauss() * 0.12 * (1 - r / 1.9);
    pos[i * 3 + 2] = Math.sin(a) * r;
    tmp.copy(cA).lerp(cB, clamp(r / 1.9 + gauss() * 0.2, 0, 1));
    const b = rand(0.8, 1.3);
    col.set([tmp.r * b, tmp.g * b, tmp.b * b], i * 3);
    size[i] = rand(0.05, 0.16);
    rnd[i] = Math.random();
  }
  mats.core = makeParticleMaterial({ alpha: 1, revealFrom: 3, swirl: 4, wobble: 0.6 });
  const pts = new THREE.Points(makeGeometry(pos, col, size, rnd), mats.core);
  pts.frustumCulled = false;
  coreGroup.add(pts);

  const tex1 = makeGlowTexture([[0, 'rgba(255,225,240,1)'], [0.25, 'rgba(255,110,190,.6)'], [0.6, 'rgba(255,40,140,.15)'], [1, 'rgba(255,40,140,0)']]);
  const tex2 = makeGlowTexture([[0, 'rgba(255,60,160,.5)'], [0.5, 'rgba(200,20,110,.12)'], [1, 'rgba(200,20,110,0)']]);
  coreGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex1, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0, fog: false }));
  coreGlow.scale.setScalar(4.6);
  coreGlow2 = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex2, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0, fog: false }));
  coreGlow2.scale.setScalar(11);
  galaxySpin.add(coreGlow2, coreGlow);
}

/* =========================================================
   9. CORAÇÃO DE PARTÍCULAS
   ========================================================= */
function heartCurve(t) {
  const x = 16 * Math.pow(Math.sin(t), 3);
  const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
  return [x, y + HEART_YOFF];
}

function createHeart() {
  heartGroup = new THREE.Group();
  heartGroup.position.set(0, HEART_Y, 0);
  scene.add(heartGroup);

  const n = Q.heart;
  const pos = new Float32Array(n * 3), col = new Float32Array(n * 3);
  const size = new Float32Array(n), rnd = new Float32Array(n);
  const tmp = new THREE.Color();

  for (let i = 0; i < n; i++) {
    const t = Math.random() * TAU;
    let [x, y] = heartCurve(t);
    const s = Math.pow(Math.random(), 0.24);   // concentra perto da borda, com poeira no miolo
    x = x * s + gauss() * 0.55;
    y = y * s + gauss() * 0.55;
    const thick = 4.2 * Math.sqrt(Math.max(0, 1 - s * s)) + 0.8;
    const z = (Math.random() * 2 - 1) * thick;
    pos.set([x, y, z], i * 3);

    const roll = Math.random();
    if (roll < 0.14) tmp.set(0xfff0f8);
    else if (roll < 0.55) tmp.set(0xff4fa3);
    else if (roll < 0.85) tmp.set(0xff2a7a);
    else tmp.set(0xffa6d2);
    const b = rand(0.7, 1.2);
    col.set([tmp.r * b, tmp.g * b, tmp.b * b], i * 3);
    size[i] = 0.035 + Math.pow(Math.random(), 3) * 0.11;
    rnd[i] = Math.random();
  }
  mats.heart = makeParticleMaterial({ alpha: 0.85, scatter: 5, wobble: 4 });
  heartPoints = new THREE.Points(makeGeometry(pos, col, size, rnd), mats.heart);
  heartPoints.scale.setScalar(HEART_SCALE);
  heartPoints.frustumCulled = false;
  heartGroup.add(heartPoints);

  // faíscas que escapam do coração
  mats.sparks = makeParticleMaterial({ life: true, pointer: 0, fog: 0 });
  sparks = createEmitter({
    heads: Q.sparks, trail: 3, spacing: 0.09, material: mats.sparks,
    colors: [0xff6cb8, 0xffe3f1, 0xff3d8a], size: [0.08, 0.17],
    spawn(i, Hh) {
      const [x, y] = heartCurve(Math.random() * TAU);
      const px = x * HEART_SCALE, py = y * HEART_SCALE;
      const len = Math.hypot(px, py) || 1;
      const sp = rand(0.25, 0.7);
      Hh.pos.set([px, py, rand(-0.5, 0.5)], i * 3);
      Hh.vel.set([(px / len) * sp, (py / len) * sp + 0.25, rand(-0.15, 0.15)], i * 3);
      Hh.dur[i] = rand(3.5, 6.5);
    },
  });
  heartGroup.add(sparks.points);
}

/* =========================================================
   10. EMISSORES (partículas escapando, com rastro)
   ========================================================= */
function createEmitter({ heads, trail, spacing, material, colors, size, spawn }) {
  const n = heads * trail;
  const pos = new Float32Array(n * 3), col = new Float32Array(n * 3);
  const siz = new Float32Array(n), rnd = new Float32Array(n), life = new Float32Array(n);
  const Hd = {
    pos: new Float32Array(heads * 3), vel: new Float32Array(heads * 3),
    age: new Float32Array(heads), dur: new Float32Array(heads),
  };
  const tmp = new THREE.Color();

  for (let i = 0; i < heads; i++) {
    spawn(i, Hd);
    Hd.age[i] = Math.random();
    tmp.set(pick(colors));
    const b = rand(0.8, 1.3), s0 = rand(size[0], size[1]);
    for (let k = 0; k < trail; k++) {
      const j = i * trail + k;
      col[j * 3] = tmp.r * b; col[j * 3 + 1] = tmp.g * b; col[j * 3 + 2] = tmp.b * b;
      siz[j] = s0 * (1 - (k / trail) * 0.6);
      rnd[j] = Math.random();
    }
  }
  const g = makeGeometry(pos, col, siz, rnd);
  const posAttr = g.getAttribute('position').setUsage(THREE.DynamicDrawUsage);
  const lifeAttr = new THREE.BufferAttribute(life, 1).setUsage(THREE.DynamicDrawUsage);
  g.setAttribute('aLife', lifeAttr);

  const points = new THREE.Points(g, material);
  points.frustumCulled = false;

  function update(dt) {
    for (let i = 0; i < heads; i++) {
      Hd.age[i] += dt / Hd.dur[i];
      if (Hd.age[i] >= 1) { spawn(i, Hd); Hd.age[i] = 0; }
      const i3 = i * 3;
      Hd.pos[i3] += Hd.vel[i3] * dt;
      Hd.pos[i3 + 1] += Hd.vel[i3 + 1] * dt;
      Hd.pos[i3 + 2] += Hd.vel[i3 + 2] * dt;
      const vx = Hd.vel[i3], vy = Hd.vel[i3 + 1], vz = Hd.vel[i3 + 2];
      const sp = Math.hypot(vx, vy, vz) || 1;
      const env = Math.pow(Math.sin(Math.PI * Hd.age[i]), 0.85);
      for (let k = 0; k < trail; k++) {
        const j = i * trail + k;
        pos[j * 3]     = Hd.pos[i3]     - (vx / sp) * k * spacing;
        pos[j * 3 + 1] = Hd.pos[i3 + 1] - (vy / sp) * k * spacing;
        pos[j * 3 + 2] = Hd.pos[i3 + 2] - (vz / sp) * k * spacing;
        life[j] = env * (1 - k / trail);
      }
    }
    posAttr.needsUpdate = true;
    lifeAttr.needsUpdate = true;
  }
  return { points, update, geometry: g };
}

function createEscapers() {
  mats.escapers = makeParticleMaterial({ life: true, pointer: 0, fog: LOOK.fogDensity });
  escapers = createEmitter({
    heads: Q.escapers, trail: 5, spacing: 0.12, material: mats.escapers,
    colors: [0xff5cab, 0xff2f9a, 0xffd0e8, 0xff7ab8], size: [0.07, 0.16],
    spawn(i, Hd) {
      const r = rand(1.5, GALAXY_R * 0.85);
      const a = Math.random() * TAU;
      const out = rand(0.25, 0.8), tang = rand(0.3, 0.9);
      Hd.pos.set([Math.cos(a) * r, rand(-0.3, 0.3), Math.sin(a) * r], i * 3);
      Hd.vel.set([
        Math.cos(a) * out - Math.sin(a) * tang,
        rand(-0.05, 0.3),
        Math.sin(a) * out + Math.cos(a) * tang,
      ], i * 3);
      Hd.dur[i] = rand(6, 13);
    },
  });
  galaxySpin.add(escapers.points);
}

/* =========================================================
   11. TEXTOS 3D (sprites com canvas) — frases orbitando
   ========================================================= */
function splitLines(text) {
  if (text.length <= 11 || !text.includes(' ')) return [text];
  const mid = text.length / 2;
  let best = -1, bd = 1e9;
  for (let i = 0; i < text.length; i++) {
    if (text[i] === ' ' && Math.abs(i - mid) < bd) { bd = Math.abs(i - mid); best = i; }
  }
  return [text.slice(0, best), text.slice(best + 1)];
}

function makeTextTexture(text) {
  const fontSize = 72, padX = 70, padY = 44, lh = fontSize * 1.3, spacing = fontSize * 0.16;
  const font = `italic 400 ${fontSize}px Georgia, "Times New Roman", serif`;
  const lines = splitLines(text);

  const meas = document.createElement('canvas').getContext('2d');
  meas.font = font;
  const widths = lines.map((ln) => [...ln].reduce((w, ch) => w + meas.measureText(ch).width + spacing, -spacing));
  const cw = Math.min(2048, Math.ceil(Math.max(...widths) + padX * 2));
  const ch = Math.ceil(lines.length * lh + padY * 2);

  const c = document.createElement('canvas');
  c.width = cw; c.height = ch;
  const ctx = c.getContext('2d');
  ctx.font = font;
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'left';

  const drawAll = () => {
    lines.forEach((ln, li) => {
      let x = (cw - widths[li]) / 2;
      const y = padY + lh * (li + 0.5);
      for (const chr of ln) { ctx.fillText(chr, x, y); x += ctx.measureText(chr).width + spacing; }
    });
  };
  ctx.shadowColor = LOOK.textGlow; ctx.shadowBlur = 26; ctx.fillStyle = LOOK.textGlow;
  drawAll(); drawAll();
  ctx.shadowColor = LOOK.textGlow; ctx.shadowBlur = 8; ctx.fillStyle = LOOK.textFill;
  drawAll();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.generateMipmaps = false;
  tex.minFilter = THREE.LinearFilter;
  return { tex, wRatio: cw / fontSize, hRatio: ch / fontSize };
}

function createTextParticles() {
  textGroup = new THREE.Group();
  galaxyTilt.add(textGroup);   // mesma inclinação da galáxia

  const n = CONFIG.phrases.length;
  CONFIG.phrases.forEach((txt, i) => {
    const { tex, wRatio, hRatio } = makeTextTexture(txt);
    const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, opacity: 0 });
    const sp = new THREE.Sprite(mat);
    sp.userData = {
      kind: 'text', idx: i,
      r: 6 + ((i * 0.618) % 1) * 9,                   // raios bem distribuídos
      theta0: i * 2.39996,                            // ângulo áureo: espalha pelo céu
      speed: rand(0.012, 0.03) * (i % 3 === 0 ? -1 : 1),
      y: (i % 2 ? 1 : -1) * rand(1.2, 4.6),
      amp: rand(0.3, 0.9),
      em: rand(0.38, 0.55),                           // menores que antes
      wRatio, hRatio, rot: rand(-0.18, 0.18),
      ph: Math.random() * TAU,
      ph2: (i / n) * TAU + rand(-0.3, 0.3),           // cada frase aparece numa hora diferente
      pulse: 0,
    };
    textGroup.add(sp);
  });
}

/* =========================================================
   12. CORAÇÕES E SÍMBOLOS FLUTUANTES
   ========================================================= */
const symbolCache = {};

function heartPath(ctx, cx, cy, s) {
  ctx.beginPath();
  for (let i = 0; i <= 64; i++) {
    const t = (i / 64) * TAU;
    const x = 16 * Math.pow(Math.sin(t), 3);
    const y = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
    const px = cx + (x * s) / 17, py = cy + ((y + 2.5) * s) / 17;
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

function getSymbolTexture(type, color) {
  const key = type + color;
  if (symbolCache[key]) return symbolCache[key];
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const ctx = c.getContext('2d');
  ctx.shadowColor = color; ctx.shadowBlur = 16; ctx.fillStyle = color; ctx.strokeStyle = color;

  if (type === 'heart') {
    heartPath(ctx, 64, 64, 78); ctx.fill();
  } else if (type === 'outline') {
    ctx.lineWidth = 5; ctx.lineJoin = 'round';
    heartPath(ctx, 64, 64, 76); ctx.stroke();
  } else if (type === 'star') {
    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const rad = i % 2 === 0 ? 46 : 9, a = (i / 8) * TAU - Math.PI / 2;
      const x = 64 + Math.cos(a) * rad, y = 64 + Math.sin(a) * rad;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath(); ctx.fill();
  } else {
    ctx.beginPath(); ctx.arc(64, 64, 14, 0, TAU); ctx.fill();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  symbolCache[key] = t;
  return t;
}

function createFloatingHearts() {
  floatGroup = new THREE.Group();
  scene.add(floatGroup);
  const types = ['heart', 'heart', 'heart', 'outline', 'outline', 'star', 'star', 'star', 'dot'];
  const colors = ['#ff5cab', '#ffe9f4', '#c58bff', '#ff3d7f', '#ff8fcb'];

  for (let i = 0; i < Q.floats; i++) {
    const near = i < 7;   // alguns bem próximos da câmera
    const mat = new THREE.SpriteMaterial({
      map: getSymbolTexture(pick(types), pick(colors)),
      transparent: true, depthWrite: false, opacity: 0, blending: THREE.AdditiveBlending,
    });
    const sp = new THREE.Sprite(mat);
    sp.userData = {
      kind: 'symbol', idx: i,
      r: near ? rand(7, 13) : rand(5, 27),
      theta0: Math.random() * TAU,
      speed: rand(0.01, 0.04) * (Math.random() < 0.5 ? -1 : 1),
      y: near ? rand(2, 10) : rand(-10, 11),
      size: near ? rand(0.7, 1.3) : rand(0.45, 1.5),
      amp: rand(0.3, 1.1), ph: Math.random() * TAU, pulse: 0,
    };
    floatGroup.add(sp);
  }
}

/* =========================================================
   12b. PLANETAS — texturas procedurais (sem imagens externas)
   ========================================================= */
/* PLANET-TEX-START */
const _perm = (() => {
  const base = Array.from({ length: 256 }, (_, i) => i);
  let seed = 1337;
  const r = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  for (let i = 255; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [base[i], base[j]] = [base[j], base[i]]; }
  const p = new Uint8Array(512);
  for (let i = 0; i < 512; i++) p[i] = base[i & 255];
  return p;
})();
const _h = (x, y, z) => _perm[_perm[_perm[x & 255] + (y & 255)] + (z & 255)] / 255;
const _sm = (t) => t * t * (3 - 2 * t);

function vnoise(x, y, z) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const xf = _sm(x - xi), yf = _sm(y - yi), zf = _sm(z - zi);
  const a = _h(xi, yi, zi), b = _h(xi + 1, yi, zi), c = _h(xi, yi + 1, zi), d = _h(xi + 1, yi + 1, zi);
  const e = _h(xi, yi, zi + 1), f = _h(xi + 1, yi, zi + 1), g = _h(xi, yi + 1, zi + 1), h = _h(xi + 1, yi + 1, zi + 1);
  const x0 = a + (b - a) * xf, x1 = c + (d - c) * xf, x2 = e + (f - e) * xf, x3 = g + (h - g) * xf;
  const y0 = x0 + (x1 - x0) * yf, y1 = x2 + (x3 - x2) * yf;
  return y0 + (y1 - y0) * zf;
}

function fbm(x, y, z, oct = 4) {
  let amp = 0.5, freq = 1, sum = 0, norm = 0;
  for (let i = 0; i < oct; i++) {
    sum += amp * vnoise(x * freq + i * 13.1, y * freq + i * 7.7, z * freq + i * 3.3);
    norm += amp; amp *= 0.5; freq *= 2.03;
  }
  return sum / norm;
}

const hex3 = (h) => [(h >> 16) & 255, (h >> 8) & 255, h & 255];
const mixc = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
const sstep = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
function ramp(stops, t) {
  if (t <= stops[0][0]) return stops[0][1];
  for (let i = 1; i < stops.length; i++) {
    if (t <= stops[i][0]) {
      const a = stops[i - 1], b = stops[i];
      return mixc(a[1], b[1], (t - a[0]) / (b[0] - a[0]));
    }
  }
  return stops[stops.length - 1][1];
}
const P = (list) => list.map(([p, h]) => [p, hex3(h)]);
const JUP = P([[0, 0x6e4227], [0.25, 0xa86a3f], [0.45, 0xd9b48a], [0.65, 0xf2e2c4], [0.85, 0xd9a36a], [1, 0xb9784a]]);
const SAT = P([[0, 0xa58d5e], [0.4, 0xd8c08a], [0.7, 0xf1e2b8], [1, 0xe6cf98]]);
const MARS = P([[0, 0x6a2e1a], [0.35, 0xa94d2b], [0.65, 0xc9703f], [1, 0xe3a56f]]);
const VEN = P([[0, 0xb8783c], [0.35, 0xe0a45a], [0.6, 0xf0cf8c], [0.85, 0xfaeac2], [1, 0xfff6de]]);
const NEP = P([[0, 0x1b3fa6], [0.5, 0x2f63d6], [1, 0x5a97ff]]);
const SPOT_A = hex3(0xb5482c), SPOT_B = hex3(0xd9744a);

/* cada função recebe um ponto da esfera (x,y,z), a latitude e a longitude e devolve [r,g,b] */
const PLANET_FN = {
  jupiter(x, y, z, lat, lon) {
    const warp = fbm(x * 2.0, y * 3.0, z * 2.0, 4);
    const streak = fbm(x * 4, y * 26, z * 4, 3);
    let t = 0.5 + 0.5 * Math.sin(y * 11 + (warp - 0.5) * 3.0);
    t = clamp(t * 0.82 + (streak - 0.5) * 0.32 + 0.09, 0, 1);
    let c = ramp(JUP, t);
    // Grande Mancha Vermelha
    let dl = lon - 3.7; dl = Math.atan2(Math.sin(dl), Math.cos(dl));
    const dy = lat + 0.33;
    const d = (dl / 0.5) ** 2 + (dy / 0.22) ** 2;
    if (d < 2.2) {
      const k = sstep(2.2, 0.6, d);
      const swirl = 0.5 + 0.5 * Math.sin(Math.atan2(dy, dl) * 3 + d * 5);
      c = mixc(c, mixc(SPOT_A, SPOT_B, swirl * (1 - d / 2.2)), k * 0.9);
    }
    return mixc(c, [110, 90, 80], sstep(0.75, 1, Math.abs(y)) * 0.45);
  },
  saturn(x, y, z) {
    const w = fbm(x * 2, y * 3, z * 2, 3);
    const streak = fbm(x * 4, y * 30, z * 4, 3);
    let t = 0.5 + 0.5 * Math.sin(y * 13 + (w - 0.5) * 2.2);
    t = clamp(t * 0.6 + (streak - 0.5) * 0.5 + 0.22, 0, 1);
    return mixc(ramp(SAT, t), [128, 132, 140], sstep(0.72, 1, Math.abs(y)) * 0.5);
  },
  mars(x, y, z, lat) {
    const n1 = fbm(x * 2.4, y * 2.4, z * 2.4, 5);
    const n2 = fbm(x * 8 + 5, y * 8, z * 8, 3);
    let c = ramp(MARS, clamp((n1 - 0.28) / 0.42, 0, 1));
    const dk = sstep(0.46, 0.36, fbm(x * 1.5 + 9, y * 1.5, z * 1.5, 4));
    c = mixc(c, [82, 36, 24], dk * 0.65);
    const g = 0.86 + 0.28 * n2;
    c = [c[0] * g, c[1] * g, c[2] * g];
    const cap = sstep(1.30 + (n2 - 0.5) * 0.3, 1.42 + (n2 - 0.5) * 0.3, Math.abs(lat));
    return mixc(c, [246, 242, 236], cap * 0.92);
  },
  venus(x, y, z) {
    const w1 = fbm(x * 1.7, y * 1.7, z * 1.7, 3);
    const w2 = fbm(x * 3.2 + w1 * 2.4, y * 3.2 + w1 * 1.4, z * 3.2 + w1 * 2.4, 5);
    let t = clamp((w2 - 0.3) / 0.4, 0, 1);
    t = clamp(t + 0.07 * Math.sin(y * 22 + w1 * 6), 0, 1);
    return ramp(VEN, t);
  },
  neptune(x, y, z, lat, lon) {
    const w = fbm(x * 2, y * 3.6, z * 2, 4);
    const band = 0.5 + 0.5 * Math.sin(y * 8 + (w - 0.5) * 3);
    let c = ramp(NEP, clamp(band * 0.55 + (w - 0.3) * 0.9, 0, 1));
    const cl = sstep(0.6, 0.78, fbm(x * 3.4 + 4, y * 13, z * 3.4, 4));
    c = mixc(c, [222, 238, 255], cl * 0.7);
    let dl = lon - 1.1; dl = Math.atan2(Math.sin(dl), Math.cos(dl));
    const d = (dl / 0.3) ** 2 + ((lat + 0.25) / 0.15) ** 2;
    return mixc(c, [16, 36, 112], sstep(1.5, 0.3, d) * 0.75);
  },
};

/* preenche linhas [j0, j1) de um mapa equirretangular RGBA (linha 0 = polo sul) */
function fillPlanetRows(kind, data, w, h, j0, j1) {
  const fn = PLANET_FN[kind];
  for (let j = j0; j < j1; j++) {
    const lat = ((j + 0.5) / h - 0.5) * Math.PI;
    const sy = Math.sin(lat), cy = Math.cos(lat);
    for (let i = 0; i < w; i++) {
      const lon = ((i + 0.5) / w) * TAU;
      const c = fn(cy * Math.cos(lon), sy, cy * Math.sin(lon), lat, lon);
      const o = (j * w + i) * 4;
      data[o] = c[0]; data[o + 1] = c[1]; data[o + 2] = c[2]; data[o + 3] = 255;
    }
  }
}
/* PLANET-TEX-END */

const PLANET_DEFS = [
  { name: 'Vênus',   kind: 'venus',   radius: 1.05, r: 7.2,  y: 1.4,  speed: 0.050, spin: 0.10, tilt: 0.05, halo: '#ffd7a0' },
  { name: 'Marte',   kind: 'mars',    radius: 0.85, r: 10.4, y: -1.6, speed: 0.036, spin: 0.16, tilt: 0.42, halo: '#ff7a4d' },
  { name: 'Júpiter', kind: 'jupiter', radius: 1.55, r: 13.0, y: 2.2,  speed: 0.028, spin: 0.24, tilt: 0.05, halo: '#ffc48a' },
  { name: 'Saturno', kind: 'saturn',  radius: 1.20, r: 8.8,  y: -2.4, speed: 0.042, spin: 0.18, tilt: 0.30, tiltX: 0.30, ring: true, halo: '#ffe3a8' },
  { name: 'Netuno',  kind: 'neptune', radius: 1.10, r: 11.8, y: 0.6,  speed: 0.033, spin: 0.14, tilt: 0.50, halo: '#6fa0ff' },
];

const PLANET_VERT = /* glsl */`
varying vec2 vUv;
varying vec3 vN;
varying vec3 vW;
void main() {
  vUv = uv;
  vN = normalize(mat3(modelMatrix) * normal);
  vec4 w = modelMatrix * vec4(position, 1.0);
  vW = w.xyz;
  gl_Position = projectionMatrix * viewMatrix * w;
}
`;

const PLANET_FRAG = /* glsl */`
uniform sampler2D uMap;
uniform vec3 uLight;
uniform vec3 uRim;
uniform float uBright;
varying vec2 vUv;
varying vec3 vN;
varying vec3 vW;
void main() {
  vec3 N = normalize(vN);
  vec3 V = normalize(cameraPosition - vW);
  // luz principal do lado da câmera (sempre mostra o planeta) + luz rosada vinda do núcleo da galáxia
  vec3 Lk = normalize(V * 0.8 + vec3(-0.55, 0.65, 0.25));
  vec3 Lc = normalize(uLight - vW);
  float dk = smoothstep(-0.2, 0.9, dot(N, Lk));
  float dc = smoothstep(-0.3, 0.9, dot(N, Lc));
  vec3 albedo = texture2D(uMap, vUv).rgb;
  vec3 col = albedo * (vec3(0.07, 0.05, 0.10) + vec3(1.0, 0.95, 0.92) * dk * 0.85 * uBright + vec3(1.0, 0.45, 0.75) * dc * 0.35 * uBright);
  float fres = pow(1.0 - max(dot(N, V), 0.0), 2.6);
  col += uRim * fres * (0.35 + 0.65 * dk) * 0.55 * uBright;
  gl_FragColor = vec4(col, 1.0);
}
`;

function makeRingTexture() {
  const S = 512, R = S / 2, inner = 1.35 / 2.5;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const ctx = c.getContext('2d');
  ctx.translate(R, R);
  ctx.lineWidth = 1.3;
  for (let r = inner * R; r < R; r += 0.75) {
    const t = (r / R - inner) / (1 - inner);
    let a = t < 0.18 ? 0.25 : t < 0.58 ? 0.85 : t < 0.64 ? 0.06 : t < 0.92 ? 0.65 : t < 0.94 ? 0.1 : 0.45;
    a *= 0.8 + 0.2 * Math.sin(t * 300);
    a *= 0.78 + 0.22 * Math.sin(t * 90) * Math.sin(t * 37 + 1);
    a *= Math.min(1, t / 0.03, (1 - t) / 0.03);
    const k = 0.5 + 0.5 * Math.sin(t * 23);
    ctx.strokeStyle = `rgba(${Math.round(lerp(196, 240, k))},${Math.round(lerp(176, 222, k))},${Math.round(lerp(136, 176, k))},${clamp(a, 0, 1)})`;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createPlanets() {
  planetGroup = new THREE.Group();
  galaxyTilt.add(planetGroup);   // órbitas no plano da galáxia

  const defs = PLANET_DEFS.slice(0, CONFIG.memories.length);
  const glowTex = makeGlowTexture([[0, 'rgba(255,255,255,1)'], [0.3, 'rgba(255,255,255,.35)'], [0.65, 'rgba(255,255,255,.08)'], [1, 'rgba(255,255,255,0)']]);
  const geo = new THREE.SphereGeometry(1, isMobile ? 40 : 64, isMobile ? 28 : 44);
  const blank = new THREE.DataTexture(new Uint8Array([255, 255, 255, 255]), 1, 1);
  blank.needsUpdate = true;
  const ringTex = defs.some((d) => d.ring) ? makeRingTexture() : null;

  defs.forEach((d, i) => {
    const group = new THREE.Group();
    const tiltG = new THREE.Group();
    tiltG.rotation.set(d.tiltX || 0, 0, d.tilt || 0);
    group.add(tiltG);

    const mat = new THREE.ShaderMaterial({
      uniforms: {
        uMap: { value: blank }, uLight: { value: new THREE.Vector3(0, 1.2, 0) },
        uRim: { value: new THREE.Color(d.halo) }, uBright: { value: 0 },
      },
      vertexShader: PLANET_VERT, fragmentShader: PLANET_FRAG,
    });
    const mesh = new THREE.Mesh(geo, mat);
    tiltG.add(mesh);

    let ring = null;
    if (d.ring) {
      ring = new THREE.Mesh(
        new THREE.RingGeometry(1.35, 2.5, 96),
        new THREE.MeshBasicMaterial({ map: ringTex, transparent: true, side: THREE.DoubleSide, depthWrite: false, opacity: 0, fog: false })
      );
      ring.rotation.x = -Math.PI / 2;
      tiltG.add(ring);
    }

    const halo = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowTex, color: d.halo, transparent: true, depthWrite: false,
      blending: THREE.AdditiveBlending, opacity: 0, fog: false,
    }));
    halo.scale.setScalar(4.4);
    group.add(halo);

    group.visible = false;
    planetGroup.add(group);
    planets.push({
      group, mesh, mat, halo, ring,
      u: {
        idx: i, name: d.name, radius: d.radius, r: d.r, y: d.y, speed: d.speed, spin: d.spin,
        theta: (i / defs.length) * TAU + 0.6, ph: Math.random() * TAU,
        pulse: 0, rv: 0, ready: false, hasRing: !!d.ring,
      },
    });
  });

  buildPlanetTextures(defs);
}

/* gera as texturas aos poucos (em fatias) para não travar a abertura */
async function buildPlanetTextures(defs) {
  const TW = isMobile ? 512 : 768, TH = TW / 2;
  for (let i = 0; i < defs.length; i++) {
    const data = new Uint8ClampedArray(TW * TH * 4);
    for (let j0 = 0; j0 < TH; j0 += 32) {
      fillPlanetRows(defs[i].kind, data, TW, TH, j0, Math.min(TH, j0 + 32));
      await new Promise((r) => setTimeout(r, 0));
    }
    const tex = new THREE.DataTexture(data, TW, TH, THREE.RGBAFormat);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.magFilter = THREE.LinearFilter;
    tex.minFilter = THREE.LinearMipmapLinearFilter;
    tex.generateMipmaps = true;
    tex.anisotropy = Math.min(4, renderer.capabilities.getMaxAnisotropy());
    tex.needsUpdate = true;
    planets[i].mat.uniforms.uMap.value = tex;
    planets[i].u.ready = true;
  }
}

/* =========================================================
   13. EXPLOSÕES AO TOCAR
   ========================================================= */
function createBurst() {
  const n = 260;
  const pos = new Float32Array(n * 3), vel = new Float32Array(n * 3);
  const col = new Float32Array(n * 3), siz = new Float32Array(n);
  const rnd = new Float32Array(n), life = new Float32Array(n);
  const age = new Float32Array(n), dur = new Float32Array(n);
  for (let i = 0; i < n; i++) rnd[i] = Math.random();

  const g = makeGeometry(pos, col, siz, rnd);
  const posAttr = g.getAttribute('position').setUsage(THREE.DynamicDrawUsage);
  const colAttr = g.getAttribute('aColor').setUsage(THREE.DynamicDrawUsage);
  const sizAttr = g.getAttribute('aSize').setUsage(THREE.DynamicDrawUsage);
  const lifeAttr = new THREE.BufferAttribute(life, 1).setUsage(THREE.DynamicDrawUsage);
  g.setAttribute('aLife', lifeAttr);

  mats.burst = makeParticleMaterial({ life: true, pointer: 0, fog: 0 });
  mats.burst.uniforms.uReveal.value = 1;
  const points = new THREE.Points(g, mats.burst);
  points.frustumCulled = false;
  scene.add(points);

  const palette = [0xff5cab, 0xffe3f1, 0xff2f9a, 0xffb0d8].map((h) => new THREE.Color(h));
  let cursor = 0;

  burst = {
    points,
    spawn(wp, count = 30, power = 1) {
      for (let c = 0; c < count; c++) {
        const j = cursor; cursor = (cursor + 1) % n;
        const th = Math.random() * TAU, ph = Math.acos(rand(-1, 1)), sp = rand(0.6, 3.2) * power;
        pos[j * 3] = wp.x; pos[j * 3 + 1] = wp.y; pos[j * 3 + 2] = wp.z;
        vel[j * 3]     = Math.sin(ph) * Math.cos(th) * sp;
        vel[j * 3 + 1] = Math.cos(ph) * sp + 0.4;
        vel[j * 3 + 2] = Math.sin(ph) * Math.sin(th) * sp;
        const cc = pick(palette), b = rand(0.9, 1.4);
        col[j * 3] = cc.r * b; col[j * 3 + 1] = cc.g * b; col[j * 3 + 2] = cc.b * b;
        siz[j] = rand(0.1, 0.28);
        age[j] = 1; dur[j] = rand(0.9, 1.8);
      }
      colAttr.needsUpdate = true; sizAttr.needsUpdate = true;
    },
    update(dt) {
      const drag = Math.max(0, 1 - 1.4 * dt);
      for (let j = 0; j < n; j++) {
        if (age[j] <= 0) continue;
        age[j] -= dt / dur[j];
        if (age[j] <= 0) { age[j] = 0; life[j] = 0; continue; }
        pos[j * 3]     += vel[j * 3] * dt;
        pos[j * 3 + 1] += vel[j * 3 + 1] * dt;
        pos[j * 3 + 2] += vel[j * 3 + 2] * dt;
        vel[j * 3] *= drag; vel[j * 3 + 1] *= drag; vel[j * 3 + 2] *= drag;
        life[j] = Math.pow(age[j], 0.7);
      }
      posAttr.needsUpdate = true; lifeAttr.needsUpdate = true;
    },
  };
}

/* =========================================================
   14. CARTÕES DE MEMÓRIA
   ========================================================= */
function createMemoryCards() {
  ui.final.querySelector('#final-title').textContent = CONFIG.finalTitle;
  ui.final.querySelector('#final-text').innerHTML = CONFIG.finalText;

  cardEls = CONFIG.memories.map((m, i) => {
    const el = document.createElement('article');
    el.className = 'card';
    el.setAttribute('aria-hidden', 'true');

    const dots = document.createElement('div');
    dots.className = 'dots';
    CONFIG.memories.forEach((_, d) => {
      const s = document.createElement('span');
      if (d === i) s.className = 'on';
      dots.appendChild(s);
    });

    const box = document.createElement('div');
    box.className = 'card-img';
    const img = document.createElement('img');
    img.alt = m.title;
    img.decoding = 'async';
    img.addEventListener('error', () => img.remove());   // sem foto: fica o coração placeholder
    img.src = m.image;
    box.appendChild(img);

    const h2 = document.createElement('h2'); h2.textContent = m.title;
    const p = document.createElement('p'); p.textContent = m.text;
    const btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'card-heart'; btn.textContent = '♥';
    btn.setAttribute('aria-label', 'Continuar');
    btn.addEventListener('click', () => closeMemory(i));

    el.append(dots, box, h2, p, btn);
    ui.cards.appendChild(el);
    return el;
  });
}

/* =========================================================
   15. CÂMERA
   ========================================================= */
const VIEWS = {
  intro: { pos: [0, 24, 54], look: [0, 1.5, 0] },
  // uma vista por etapa (0 a 5 lembranças abertas); a última é mais aberta
  gal: [
    { pos: [0, 12.5, 23], look: [0, 2.2, 0] },
    { pos: [-11, 8, 18], look: [0, 2.2, 0] },
    { pos: [11, 15, 17], look: [0, 2.2, 0] },
    { pos: [-6, 17, 26], look: [0, 2.2, 0] },
    { pos: [8, 10, 20], look: [0, 2.2, 0] },
    { pos: [0, 20, 36], look: [0, 2.0, 0] },
  ],
  final: { pos: [0, 13, 35], look: [0, 2.6, 0] },
};
const memoryView = (i) => ({ pos: [(i - 1) * 4, 3.5 + i * 1.2, 9.5], look: [0, 2.4, 0] });

function applyView() {
  if (!cam.view) return;
  const k = cam.soft ? fitSoft : fit;
  const look = new THREE.Vector3(...cam.view.look);
  const off = new THREE.Vector3(...cam.view.pos).sub(look).multiplyScalar(k);
  cam.tLook.copy(look);
  cam.tPos.copy(look).add(off);
}

function setView(view, { rate = 0.9, soft = false } = {}) {
  cam.view = view; cam.rate = rate; cam.soft = soft;
  applyView();
}

function snapCamera() {
  cam.pos.copy(cam.tPos); cam.look.copy(cam.tLook);
}

function setupCamera() {
  setView(VIEWS.intro, { rate: 0.4 });
}

function updateCamera(dt) {
  const a = 1 - Math.exp(-cam.rate * dt);
  cam.pos.lerp(cam.tPos, a);
  cam.look.lerp(cam.tLook, a);

  const sway = reducedMotion ? 0 : 1;
  const k = fitSoft;
  const ox = (Math.sin(time * 0.15) * 0.5 + parallax.x * 1.6) * k * sway + (reducedMotion ? parallax.x * 1.6 * k : 0);
  const oy = (Math.cos(time * 0.12) * 0.3 + parallax.y * 1.0) * k * sway + (reducedMotion ? parallax.y * k : 0);
  camera.position.set(cam.pos.x + ox, cam.pos.y + oy, cam.pos.z);
  camera.lookAt(cam.look);
}

/* =========================================================
   16. PÓS-PROCESSAMENTO (bloom / glow neon)
   ========================================================= */
function setupPostProcessing() {
  const rt = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType, samples: isMobile ? 0 : 4 });
  composer = new EffectComposer(renderer, rt);
  composer.setPixelRatio(Q.pixelRatio);
  composer.setSize(W, H);
  composer.addPass(new RenderPass(scene, camera));
  bloomPass = new UnrealBloomPass(
    new THREE.Vector2(W, H),
    isMobile ? LOOK.bloomStrength * 0.9 : LOOK.bloomStrength,
    LOOK.bloomRadius, LOOK.bloomThreshold
  );
  composer.addPass(bloomPass);
  composer.addPass(new OutputPass());
}

/* =========================================================
   17. CONTROLES E INTERAÇÃO
   ========================================================= */
function setupControls() {
  ui.enter.addEventListener('click', startExperience);
  ui.next.addEventListener('click', advance);
  ui.replay.addEventListener('click', replay);
  ui.sound.addEventListener('click', toggleMusic);
  ui.music.addEventListener('error', () => ui.sound.classList.add('hidden'));

  window.addEventListener('resize', handleResize);
  window.addEventListener('orientationchange', () => setTimeout(handleResize, 200));
  window.addEventListener('pointermove', handlePointerMove, { passive: true });
  document.addEventListener('mouseleave', () => { if (!pointer.isTouch) pointer.active = false; });
  ui.canvas.addEventListener('pointerdown', handlePointerDown);
  ui.canvas.addEventListener('touchstart', handleTouch, { passive: false });
  ui.canvas.addEventListener('touchmove', handleTouch, { passive: false });
  ui.canvas.addEventListener('touchend', releasePointer);
  ui.canvas.addEventListener('touchcancel', releasePointer);
  window.addEventListener('pagehide', disposeAll);
}

function setPointer(x, y) {
  pointer.tx = (x / W) * 2 - 1;
  pointer.ty = -((y / H) * 2 - 1);
}

function handlePointerMove(e) {
  if (e.pointerType === 'touch') return;   // toque é tratado em handleTouch
  pointer.isTouch = false;
  pointer.active = true;
  setPointer(e.clientX, e.clientY);
  if (phase === 'galaxy') {   // mãozinha ao passar em cima de planetas, frases e corações
    ui.canvas.style.cursor = (pickPlanet(e.clientX, e.clientY) || pickAt(e.clientX, e.clientY)) ? 'pointer' : 'default';
  }
}

function handleTouch(e) {
  if (e.cancelable) e.preventDefault();
  const t = e.touches[0];
  if (!t) return;
  pointer.isTouch = true;
  pointer.active = true;
  setPointer(t.clientX, t.clientY);
}

function releasePointer() {
  if (pointer.isTouch) pointer.active = false;
}

function updateControls(dt) {
  const a = 1 - Math.exp(-8 * dt);
  pointer.x += (pointer.tx - pointer.x) * a;
  pointer.y += (pointer.ty - pointer.y) * a;
  shared.uPointer.value.set(pointer.x, pointer.y);
  shared.uPointerStr.value += ((pointer.active ? 1 : 0) - shared.uPointerStr.value) * (1 - Math.exp(-4 * dt));

  const pa = 1 - Math.exp(-2.5 * dt);
  const tx = pointer.active ? pointer.tx : 0, ty = pointer.active ? pointer.ty : 0;
  parallax.x += (tx - parallax.x) * pa;
  parallax.y += (ty - parallax.y) * pa;
}

/* ---- toques nas frases, corações e coração principal ---- */
const _v = new THREE.Vector3();
const _w = new THREE.Vector3();

function pxPerUnit(worldPos) {
  _v.copy(worldPos).applyMatrix4(camera.matrixWorldInverse);
  const dist = Math.max(0.1, -_v.z);
  return H / (2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * dist);
}

function pickAt(x, y) {
  let best = null, bestD = Infinity;
  const test = (sp) => {
    if (sp.material.opacity < 0.25) return;
    sp.getWorldPosition(_w);
    _v.copy(_w).project(camera);
    if (_v.z > 1 || _v.z < -1) return;
    const sx = (_v.x * 0.5 + 0.5) * W, sy = (-_v.y * 0.5 + 0.5) * H;
    const ppu = pxPerUnit(_w);
    const halfW = Math.max(sp.userData.kind === 'text' ? sp.scale.x * ppu * 0.32 : 0, 34);
    const halfH = Math.max(sp.scale.y * ppu * 0.3, 28);
    const dx = (x - sx) / halfW, dy = (y - sy) / halfH;
    const d = dx * dx + dy * dy;
    if (d <= 1 && d < bestD) { bestD = d; best = sp; }
  };
  textGroup.children.forEach(test);
  floatGroup.children.forEach(test);
  return best;
}

function worldAtPointer(x, y) {
  const ndc = new THREE.Vector3((x / W) * 2 - 1, -((y / H) * 2 - 1), 0.5).unproject(camera);
  const dir = ndc.sub(camera.position).normalize();
  const dist = camera.position.distanceTo(cam.look);
  return camera.position.clone().add(dir.multiplyScalar(dist));
}

function pickPlanet(x, y) {
  let best = null, bestD = Infinity;
  planets.forEach((p) => {
    if (!p.u.ready || p.u.rv < 0.6) return;
    p.group.getWorldPosition(_w);
    _v.copy(_w).project(camera);
    if (_v.z > 1 || _v.z < -1) return;
    const sx = (_v.x * 0.5 + 0.5) * W, sy = (-_v.y * 0.5 + 0.5) * H;
    const rad = Math.max(p.u.radius * planetScale * pxPerUnit(_w) * (p.u.hasRing ? 1.9 : 1.3), 38);
    const d = Math.hypot(x - sx, y - sy) / rad;
    if (d <= 1 && d < bestD) { bestD = d; best = p; }
  });
  return best;
}

function handlePointerDown(e) {
  if (phase !== 'galaxy' && phase !== 'final') return;
  const x = e.clientX, y = e.clientY;

  if (phase === 'galaxy') {
    const pl = pickPlanet(x, y);
    if (pl) { openMemory(pl.u.idx); return; }
  }

  const hit = pickAt(x, y);
  if (hit) {
    hit.getWorldPosition(_w);
    hit.userData.pulse = 1;
    burst.spawn(_w.clone(), 38, 1);
    return;
  }
  // coração principal
  heartGroup.getWorldPosition(_w);
  _v.copy(_w).project(camera);
  const sx = (_v.x * 0.5 + 0.5) * W, sy = (-_v.y * 0.5 + 0.5) * H;
  const ppu = pxPerUnit(_w);
  const rx = 4.2 * ppu * heartGroup.scale.x, ry = 3.8 * ppu * heartGroup.scale.x;
  if (((x - sx) / rx) ** 2 + ((y - sy) / ry) ** 2 <= 1) {
    heartState.kick = 1;
    burst.spawn(_w.clone(), 60, 1.4);
    return;
  }
  burst.spawn(worldAtPointer(x, y), 12, 0.6);   // toque no vazio: pequeno brilho
}

/* =========================================================
   18. FLUXO: INTRO → GALÁXIA → MEMÓRIA → ... → FINAL
   ========================================================= */
function after(ms, fn) { const id = setTimeout(fn, ms); timers.push(id); return id; }
function clearTimers() { timers.splice(0).forEach(clearTimeout); }

function startExperience() {
  if (phase !== 'intro') return;
  enterAt = time;
  ui.intro.classList.add('hide');
  ui.sound.classList.add('show');
  startMusic();
  goGalaxy(true);
  after(4200, () => ui.hint.classList.add('show'));
  after(12000, () => ui.hint.classList.remove('show'));
}

function goGalaxy(first = false) {
  clearTimers();
  phase = 'galaxy';
  memIndex = -1;
  ui.veil.classList.remove('on');
  ui.cards.classList.remove('on');
  cardEls.forEach((c) => { c.classList.remove('show'); c.setAttribute('aria-hidden', 'true'); });
  ui.next.classList.remove('show');

  const done = visited.size >= CONFIG.memories.length;
  ui.next.textContent = done ? CONFIG.ui.finish : CONFIG.ui.next;
  setView(VIEWS.gal[Math.min(visited.size, VIEWS.gal.length - 1)], { rate: first ? 0.5 : 0.8 });
  after(first ? 11000 : done ? 3500 : 6000, () => ui.next.classList.add('show'));
}

/* botão do rodapé: abre a próxima lembrança ainda não vista (ou vai para o final) */
function advance() {
  if (phase !== 'galaxy') return;
  const next = CONFIG.memories.findIndex((_, i) => !visited.has(i));
  if (next === -1) {
    clearTimers();
    ui.next.classList.remove('show');
    ui.hint.classList.remove('show');
    showFinal();
  } else {
    openMemory(next);
  }
}

/* toque num planeta: a câmera voa até ele e abre o photocard */
function openMemory(i) {
  if (phase !== 'galaxy' || !planets[i]) return;
  clearTimers();
  phase = 'memory';
  memIndex = i;
  ui.next.classList.remove('show');
  ui.hint.classList.remove('show');

  const p = planets[i];
  p.group.getWorldPosition(_w);
  const target = _w.clone();
  const dir = camera.position.clone().sub(target).normalize();
  const dist = 5 + p.u.radius * planetScale * 2.4;
  setView({ pos: target.clone().addScaledVector(dir, dist).toArray(), look: target.toArray() }, { rate: 1.2, soft: true });
  p.u.pulse = 1;
  burst.spawn(target, 46, 1.2);

  ui.veil.classList.add('on');
  after(800, () => {
    ui.cards.classList.add('on');
    cardEls[i].classList.add('show');
    cardEls[i].setAttribute('aria-hidden', 'false');
  });
}

function closeMemory(i) {
  if (phase !== 'memory') return;
  phase = 'transition';
  visited.add(i);
  cardEls[i].classList.remove('show');
  ui.veil.classList.remove('on');
  after(800, () => goGalaxy());
}

function showFinal() {
  phase = 'final';
  setView(VIEWS.final, { rate: 0.6 });
  heartState.target = 1.3;
  after(1200, () => ui.final.classList.add('show'));
}

function replay() {
  if (phase !== 'final') return;
  ui.final.classList.remove('show');
  heartState.target = 1;
  visited.clear();
  phase = 'transition';
  after(900, () => goGalaxy());
}

/* ---- música opcional ---- */
function syncSound() { ui.sound.textContent = musicOn ? '🔊' : '🔇'; }

function startMusic() {
  const a = ui.music;
  a.volume = 0.6;
  const p = a.play();
  if (p && p.then) {
    p.then(() => { musicOn = true; syncSound(); })
     .catch(() => { if (a.error) ui.sound.classList.add('hidden'); });
  }
}

function toggleMusic() {
  const a = ui.music;
  if (a.paused) {
    const p = a.play();
    if (p && p.then) p.then(() => { musicOn = true; syncSound(); }).catch(() => {});
  } else {
    a.pause(); musicOn = false; syncSound();
  }
}

/* =========================================================
   19. ANIMAÇÃO
   ========================================================= */
function updateReveal() {
  if (enterAt === null) return;
  const t = time - enterAt;
  const seg = (a, d) => easeInOut(clamp((t - a) / d, 0, 1));
  reveal.stars = seg(0.3, 1.8);
  reveal.galaxy = seg(1.0, 2.6);
  reveal.haze = seg(1.3, 2.6);
  reveal.core = seg(1.5, 1.8);
  reveal.heart = seg(2.0, 2.2);
  reveal.floats = seg(2.3, 1.8);
  reveal.sparks = seg(2.8, 1.6);
  reveal.escapers = seg(3.0, 2.0);
  reveal.textT = t - 2.5;

  mats.stars.uniforms.uReveal.value = reveal.stars;
  mats.galaxy.uniforms.uReveal.value = reveal.galaxy;
  mats.haze.uniforms.uReveal.value = reveal.haze;
  mats.core.uniforms.uReveal.value = reveal.core;
  mats.heart.uniforms.uReveal.value = reveal.heart;
  mats.sparks.uniforms.uReveal.value = reveal.sparks;
  mats.escapers.uniforms.uReveal.value = reveal.escapers;
}

function updateWorld(dt) {
  starsGroup.rotation.y += dt * 0.004;
  starsGroup.rotation.x = Math.sin(time * 0.02) * 0.03;

  galaxySpin.rotation.y += dt * LOOK.galaxySpinSpeed;
  coreGroup.rotation.y += dt * 0.35;
  coreGlow.material.opacity = reveal.core * (0.78 + Math.sin(time * 1.6) * 0.1);
  coreGlow2.material.opacity = reveal.core * (0.5 + Math.sin(time * 1.1) * 0.08);

  // frases: pequenas, em destaque, aparecem, passam e somem suavemente (como os corações)
  textGroup.children.forEach((sp) => {
    const u = sp.userData;
    const th = u.theta0 + time * u.speed;
    sp.position.set(Math.cos(th) * u.r, u.y + Math.sin(time * 0.5 + u.ph) * u.amp, Math.sin(th) * u.r);
    const k = u.em * textScale * (1 + Math.sin(time * 0.6 + u.ph) * 0.04) * (1 + 0.45 * u.pulse);
    sp.scale.set(u.wRatio * k, u.hRatio * k, 1);
    sp.material.rotation = u.rot + Math.sin(time * 0.25 + u.ph) * 0.05;
    const ti = clamp((reveal.textT - u.idx * 0.3) / 1.4, 0, 1);
    const vis = sstep(-0.35, 0.35, Math.sin(time * 0.22 + u.ph2));
    sp.material.opacity = easeInOut(ti) * vis * 0.92;
    u.pulse *= Math.exp(-3 * dt);
  });

  // planetas: órbita lenta, giro próprio, halo que pulsa nos que ainda não foram abertos
  planetMotion += ((phase === 'memory' ? 0 : 1) - planetMotion) * (1 - Math.exp(-2.5 * dt));
  planets.forEach((p) => {
    const u = p.u;
    if (!u.ready) return;
    u.theta += dt * u.speed * planetMotion;
    p.group.position.set(Math.cos(u.theta) * u.r, u.y + Math.sin(time * 0.35 + u.ph) * 0.3, Math.sin(u.theta) * u.r);
    u.rv = easeOut(clamp((reveal.textT - 0.3 - u.idx * 0.4) / 1.8, 0, 1));
    p.group.visible = u.rv > 0.01;
    p.group.scale.setScalar(u.radius * planetScale * (0.3 + 0.7 * u.rv) * (1 + 0.16 * u.pulse));
    p.mesh.rotation.y += dt * u.spin;
    p.mat.uniforms.uBright.value = u.rv * LOOK.planetBrightness;
    const glow = visited.has(u.idx) ? 0.3 : 0.45 + 0.2 * Math.sin(time * 1.6 + u.ph);
    p.halo.material.opacity = u.rv * glow;
    if (p.ring) p.ring.material.opacity = u.rv * 0.9;
    u.pulse *= Math.exp(-3 * dt);
  });

  // corações / símbolos flutuantes
  floatGroup.children.forEach((sp) => {
    const u = sp.userData;
    const th = u.theta0 + time * u.speed;
    sp.position.set(Math.cos(th) * u.r, u.y + Math.sin(time * 0.5 + u.ph) * u.amp, Math.sin(th) * u.r);
    const k = u.size * textScale * (0.92 + Math.sin(time * 0.9 + u.ph) * 0.08) * (1 + 0.5 * u.pulse);
    sp.scale.set(k, k, 1);
    sp.material.opacity = reveal.floats * (0.45 + 0.5 * (0.5 + 0.5 * Math.sin(time * 1.1 + u.ph * 3)));
    u.pulse *= Math.exp(-3 * dt);
  });

  // coração principal: pulsação suave + leve giro
  heartState.boost += (heartState.target - heartState.boost) * (1 - Math.exp(-1.2 * dt));
  heartState.kick *= Math.exp(-4 * dt);
  const pulse = 1 + Math.sin(time * 2.0) * 0.035 + heartState.kick * 0.12;
  heartGroup.scale.setScalar((0.55 + 0.45 * reveal.heart) * pulse * heartState.boost);
  heartGroup.rotation.y = Math.sin(time * 0.35) * 0.4;

  escapers.update(dt);
  sparks.update(dt);
  burst.update(dt);
}

function perfGuard(dt) {
  if (perf.done || enterAt === null || document.hidden) return;
  const t = time - enterAt;
  if (t < 4) return;
  if (t < 8) { perf.acc += Math.min(dt, 0.1); perf.n++; return; }
  perf.done = true;
  const avg = perf.acc / Math.max(1, perf.n);
  if (avg > 1 / 30) {   // menos de ~30 fps: reduz qualidade automaticamente
    galaxyPoints.geometry.setDrawRange(0, Math.floor(Q.galaxy * 0.6));
    hazePoints.geometry.setDrawRange(0, Math.floor(Q.haze * 0.5));
    heartPoints.geometry.setDrawRange(0, Math.floor(Q.heart * 0.7));
    currentPR = 1;
    bloomPass.strength *= 0.85;
    handleResize();
  }
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);
  time += dt;
  shared.uTime.value = time;

  updateReveal();
  updateControls(dt);
  updateCamera(dt);
  updateWorld(dt);
  perfGuard(dt);

  composer.render(dt);
}

/* =========================================================
   20. RESIZE
   ========================================================= */
function handleResize() {
  W = window.innerWidth; H = window.innerHeight; aspect = W / H;
  camera.aspect = aspect;
  camera.updateProjectionMatrix();

  renderer.setPixelRatio(currentPR);
  renderer.setSize(W, H, false);
  composer.setPixelRatio(currentPR);
  composer.setSize(W, H);

  shared.uScale.value = H * currentPR * 0.5;
  shared.uAspect.value = aspect;

  // retrato: afasta a câmera e aumenta os textos para tudo caber e continuar legível
  fit = aspect < 1 ? Math.pow(1 / aspect, 0.75) : 1;
  fitSoft = 1 + (fit - 1) * 0.5;
  textScale = 1 + (fit - 1) * 0.9;
  planetScale = 1 + (fit - 1) * 0.75;
  applyView();
}

/* =========================================================
   21. LIMPEZA
   ========================================================= */
function disposeAll() {
  scene.traverse((o) => {
    if (o.geometry) o.geometry.dispose();
    if (o.material && o.material.map) o.material.map.dispose();
    if (o.material && !materials.includes(o.material)) o.material.dispose();
  });
  planets.forEach((p) => { p.mat.dispose(); if (p.mat.uniforms.uMap.value) p.mat.uniforms.uMap.value.dispose(); });
  materials.forEach((m) => m.dispose());
  Object.values(symbolCache).forEach((t) => t.dispose());
  composer.dispose();
  renderer.dispose();
}

init();
